response = "y"

rot = []
pos = []

add_rot = [-4.5, -1.5, -3.5]
add_pos = [-1.6105, -0.1792, 0.75]

def convert() :
    for i in range(0,3):
        item = input("rot "+str(i)+" ")
        rot.append(float(item))
        
    for i in range(0,3):
        item = input("pos "+str(i)+" ")
        pos.append(float(item))

    for i in range(0,3):
        rot[i] = rot[i] + add_rot[i]

    for i in range(0,3):
        pos[i] = pos[i] + add_pos[i]

    print(rot)
    print(pos)

while response == "y":
    convert()
    response = input("cont? ")
    rot = []
    pos = []
